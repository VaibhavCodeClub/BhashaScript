# BhashaScript
---
A small effort to make simple Marathi programming language for fun built using python3.

I attached some screenshots to make sure you get actual idea of what is going on here.

### Tokens
![tokens](SS/token.png) .
